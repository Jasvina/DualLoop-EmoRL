# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import gc
import logging
import torch
from torch.distributed.fsdp.fully_sharded_data_parallel import FullyShardedDataParallel as FSDP
from torch.distributed.fsdp.api import ShardingStrategy, ShardedStateDictConfig, StateDictType, FullStateDictConfig
from torch.distributed.device_mesh import DeviceMesh
import numpy as np


from verl.third_party.vllm import LLM
from verl.third_party.vllm import parallel_state as vllm_ps
from verl import DataProto
from verl.utils.torch_functional import (broadcast_dict_tensor, allgather_dict_tensors)
from verl.utils.debug import log_gpu_memory_usage
from verl.third_party.vllm import vllm_version

from .base import BaseShardingManager

logger = logging.getLogger(__file__)
logger.setLevel(os.getenv('VERL_PPO_LOGGING_LEVEL', 'WARN'))


class FSDPVLLMShardingManager(BaseShardingManager):

    def __init__(self,
                 module: FSDP,
                 inference_engine: LLM,
                 model_config,
                 full_params: bool = False,
                 device_mesh: DeviceMesh = None):
        self.module = module
        self.inference_engine = inference_engine
        self.model_config = model_config
        self.device_mesh = device_mesh

        # Full params
        self.full_params = full_params
        if full_params:
            FSDP.set_state_dict_type(self.module,
                                     state_dict_type=StateDictType.FULL_STATE_DICT,
                                     state_dict_config=FullStateDictConfig())
        else:
            FSDP.set_state_dict_type(self.module,
                                     state_dict_type=StateDictType.SHARDED_STATE_DICT,
                                     state_dict_config=ShardedStateDictConfig())

        # Note that torch_random_states may be different on each dp rank
        self.torch_random_states = torch.cuda.get_rng_state()
        # get a random rng states
        if self.device_mesh is not None:
            gen_dp_rank = self.device_mesh['dp'].get_local_rank()
            torch.cuda.manual_seed(gen_dp_rank + 1000)  # make sure all tp ranks have the same random states
            self.gen_random_states = torch.cuda.get_rng_state()
            torch.cuda.set_rng_state(self.torch_random_states)
        else:
            self.gen_random_states = None

    def __enter__(self):
        log_gpu_memory_usage('Before state_dict() in sharding manager memory', logger=logger)
        # Aggressively free PyTorch cached memory before loading vLLM weights
        gc.collect()
        torch.cuda.empty_cache()
        params = self.module.state_dict()
        log_gpu_memory_usage('After state_dict() in sharding manager memory', logger=logger)
        # Copy, not share memory
        load_format = 'hf' if self.full_params else 'dtensor'
        if vllm_version in ('0.4.2', '0.5.4', '0.6.3'):
            self.inference_engine.sync_model_weights(params, load_format=load_format)
        else:
            self.inference_engine.wake_up()
            # TODO(ZSL): deal with 'hf' format
            if load_format == 'dtensor':
                from verl.third_party.vllm import load_dtensor_weights
                load_dtensor_weights(
                    params, self.inference_engine.llm_engine.model_executor.driver_worker.worker.model_runner.model)
            else:
                raise NotImplementedError(f'load_format {load_format} not implemented')
        log_gpu_memory_usage('After sync model weights in sharding manager', logger=logger)

        del params
        torch.cuda.empty_cache()
        log_gpu_memory_usage('After del state_dict and empty_cache in sharding manager', logger=logger)

        # TODO: offload FSDP model weights
        # self.module.cpu()
        # torch.cuda.empty_cache()
        # if torch.distributed.get_rank() == 0:
        # print(f'after model to cpu in sharding manager memory allocated: {torch.cuda.memory_allocated() / 1e9}GB, reserved: {torch.cuda.memory_reserved() / 1e9}GB')

        # important: need to manually set the random states of each tp to be identical.
        if self.device_mesh is not None:
            self.torch_random_states = torch.cuda.get_rng_state()
            torch.cuda.set_rng_state(self.gen_random_states)

    def __exit__(self, exc_type, exc_value, traceback):
        log_gpu_memory_usage('Before vllm offload in sharding manager', logger=logger)
        # TODO(ZSL): check this
        if vllm_version in ('0.4.2', '0.5.4', '0.6.3'):
            self.inference_engine.offload_model_weights()
        else:
            self.inference_engine.sleep(level=1)
        log_gpu_memory_usage('After vllm offload in sharding manager', logger=logger)

        # self.module.to('cuda')
        # if torch.distributed.get_rank() == 0:
        #     print(f'after actor module to cuda in sharding manager memory allocated: {torch.cuda.memory_allocated() / 1e9}GB, reserved: {torch.cuda.memory_reserved() / 1e9}GB')

        self.module.train()

        # add empty cache after each compute
        torch.cuda.empty_cache()

        # restore random states
        if self.device_mesh is not None:
            self.gen_random_states = torch.cuda.get_rng_state()
            torch.cuda.set_rng_state(self.torch_random_states)

    def preprocess_data(self, data: DataProto) -> DataProto:
        # TODO: Current impl doesn't consider FSDP with torch micro-dp
        tp_world_size = vllm_ps.get_tensor_model_parallel_world_size()
        if tp_world_size <= 1:
            # No need to allgather when TP=1
            pass
        elif vllm_version in ('0.3.1', '0.4.2', '0.5.4', '0.6.3'):
            data.batch = allgather_dict_tensors(data.batch.contiguous(),
                                                size=tp_world_size,
                                                group=vllm_ps.get_tensor_model_parallel_group(),
                                                dim=0)
        else:
            # vLLM >= 0.7: get_tensor_model_parallel_group() -> get_tp_group()
            tp_group = vllm_ps.get_tp_group()
            group = getattr(tp_group, 'device_group', tp_group)
            data.batch = allgather_dict_tensors(data.batch.contiguous(),
                                                size=tp_world_size,
                                                group=group,
                                                dim=0)

        if data.non_tensor_batch is not None and len(data.non_tensor_batch) > 0 and tp_world_size > 1:
            print(f"data.non_tensor_batch: {data.non_tensor_batch}")
            world_size = tp_world_size
            print(f"world_size: {world_size}")
            gathered_non_tensor = {}
            # Loop over each key in the non-tensor batch.
            for key, val in data.non_tensor_batch.items():
                # Prepare a list to hold the gathered numpy arrays.
                gathered = [None for _ in range(world_size)]
                # Use all_gather_object to collect the numpy arrays from all ranks.
                if vllm_version in ('0.3.1', '0.4.2', '0.5.4', '0.6.3'):
                    torch.distributed.all_gather_object(gathered, val, group=vllm_ps.get_tensor_model_parallel_group())
                else:
                    tp_group = vllm_ps.get_tp_group()
                    group = getattr(tp_group, 'device_group', tp_group)
                    torch.distributed.all_gather_object(gathered, val, group=group)
                # Concatenate the gathered numpy arrays along the first dimension.
                gathered_non_tensor[key] = np.concatenate(gathered, axis=0)
            data.non_tensor_batch = gathered_non_tensor

        return data

    def postprocess_data(self, data: DataProto) -> DataProto:
        # TODO: Current impl doesn't consider FSDP with torch micro-dp
        local_world_size = vllm_ps.get_tensor_model_parallel_world_size()
        if local_world_size > 1:
            src_rank = (torch.distributed.get_rank() // local_world_size) * local_world_size
            if vllm_version in ('0.3.1', '0.4.2', '0.5.4', '0.6.3'):
                broadcast_dict_tensor(data.batch, src=src_rank, group=vllm_ps.get_tensor_model_parallel_group())
            else:
                tp_group = vllm_ps.get_tp_group()
                group = getattr(tp_group, 'device_group', tp_group)
                broadcast_dict_tensor(data.batch, src=src_rank, group=group)
        dp_rank = torch.distributed.get_rank()
        dp_size = torch.distributed.get_world_size()  # not consider torch micro-dp
        tp_size = local_world_size
        if tp_size > 1:
            # TODO: shall we build a micro_dp group for vllm when integrating with vLLM?
            local_prompts = data.chunk(chunks=tp_size)
            data = local_prompts[dp_rank % tp_size]
        return data
